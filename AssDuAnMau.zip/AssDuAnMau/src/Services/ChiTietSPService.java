/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Services;

import Repositories.SanPhamResponsitory;
import java.util.List;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ADMIN
 */
public interface ChiTietSPService {
    void showData(List<DomainModel.ChiTietSP> list,DefaultTableModel dtm);
    void getAll(List<DomainModel.ChiTietSP> list);
    String delete(String id);
    String addSPCT(DomainModel.ChiTietSP sp);
    void layNSXcbb(List<String> list);
    void layMauSaccbb(List<String> list);
    void layDongSPcbb(List<String> list);
    String addSP(DomainModel.LoaiSP sp);
}
