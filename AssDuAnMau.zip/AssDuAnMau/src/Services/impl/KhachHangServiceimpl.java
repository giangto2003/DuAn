/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Services.impl;

import java.util.List;
import DomainModel.KhachHang;
import Repositories.KhachHangResponsitory;
import Services.KhachHangService;

/**
 *
 * @author ADMIN
 */
public class KhachHangServiceimpl implements KhachHangService{
private KhachHangResponsitory khr=new KhachHangResponsitory();
    @Override
    public void getall(List<DomainModel.KhachHang> list) {
        list.addAll(khr.getAll());
    }

    @Override
    public String add(KhachHang kh) {
        boolean add=khr.add(kh);
        if(add==true){
            return "Đăng kí thành công";
        }else{
            return "Đăng kí thất bại";
        }
    }

    @Override
    public String layIDKH(String maKH) {
        return khr.layIDKH(maKH);
    }
    
}
