/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Services.impl;

import java.util.List;
import javax.swing.DefaultComboBoxModel;
import Repositories.SanPhamResponsitory;
import Services.LoaiSP;

/**
 *
 * @author ADMIN
 */
public class LoaiSPServiceimpl implements LoaiSP {

    SanPhamResponsitory rs = new SanPhamResponsitory();

    @Override
    public void getAll(List<DomainModel.LoaiSP> list) {
        list.addAll(rs.getAllLoaiSP());
    }

    @Override
    public void layNSXcbb(List<String> list) {
        list.addAll(rs.layNSXcbb());
    }

    @Override
    public void layMauSaccbb(List<String> list) {
        list.addAll(rs.layMauSaccbb());
    }

    @Override
    public void layDongSPcbb(List<String> list) {
        list.addAll(rs.layDongSPcbb());
    }

}
