/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Services.impl;

import java.util.List;
import javax.swing.table.DefaultTableModel;
import DomainModel.ChiTietSP;
import Repositories.SanPhamResponsitory;
import Services.ChiTietSPService;
import Services.LoaiSP;

/**
 *
 * @author ADMIN
 */
public class ChiTietSPServiceimpl implements ChiTietSPService{
    SanPhamResponsitory sanPhamResponsitory = new SanPhamResponsitory();

    @Override
    public void showData(List<DomainModel.ChiTietSP> list, DefaultTableModel dtm) {
        dtm.setRowCount(0);
        for(ChiTietSP sp:list){
            dtm.addRow(sp.toDataRow());
        }
    }

    @Override
    public void getAll(List<DomainModel.ChiTietSP> list) {
        list.addAll(sanPhamResponsitory.getAll());
    }

    @Override
    public String delete(String id) {
        boolean delete=sanPhamResponsitory.deleteSP(id);
        if(delete==true){
            return "Xóa thành công";
        }else{
            return "Xóa thất bại";
        }
    }

    @Override
    public String addSPCT(DomainModel.ChiTietSP sp) {
        boolean add=sanPhamResponsitory.addSPCT(sp);
        if(add){
            return "Thêm thành công";
        }else{
            return "Thêm thất bại";
        }
    }
    

    @Override
    public void layNSXcbb(List<String> list) {
        list.addAll(sanPhamResponsitory.layNSXcbb());
    }

    @Override
    public void layMauSaccbb(List<String> list) {
        list.addAll(sanPhamResponsitory.layMauSaccbb());
    }

    @Override
    public void layDongSPcbb(List<String> list) {
        list.addAll(sanPhamResponsitory.layDongSPcbb());
    }

    @Override
    public String addSP(DomainModel.LoaiSP sp) {
        boolean add=sanPhamResponsitory.addSP(sp);
        if(add){
            return "Thêm SP thành công";
        }else{
            return "Thêm SP thất bại";
        }
    }

    
    
}
