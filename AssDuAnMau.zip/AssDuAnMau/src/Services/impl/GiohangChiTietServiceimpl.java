/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Services.impl;

import DomainModel.GioHangChiTiet;
import Repositories.GioHangChiTietRepository;
import Services.GioHangChiTietService;
import java.security.spec.NamedParameterSpec;
import java.util.List;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ADMIN
 */
public class GiohangChiTietServiceimpl implements GioHangChiTietService{
    GioHangChiTietRepository sealed =new GioHangChiTietRepository();
    @Override
    public void getAll(List<GioHangChiTiet> list,String idKH) {
        list.addAll(sealed.getAll(idKH));
    }

    @Override
    public void showData(List<GioHangChiTiet> list, DefaultTableModel dtm) {
        dtm.setRowCount(0);
        for(GioHangChiTiet x:list){
            dtm.addRow(x.toDataRow());
        }
    }

    @Override
    public String layIdGioHang(String maKH) {
        return sealed.layIDGioHang(maKH);
    }

    @Override
    public String layIdSanPham(String idSP) {
        return sealed.layIDSP(idSP);
    }

    @Override
    public String layMaGioHang(String id) {
        return sealed.layMaGioHang(id);
    }

    @Override
    public String layTenSanPham(String id) {
        return sealed.layTenSP(id);
    }
    
}
