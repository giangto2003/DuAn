/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Services.impl;

import java.util.List;
import DomainModel.NhanVien;
import Repositories.NhanVienResponsitoty;
import Services.NhanVienService;

/**
 *
 * @author ADMIN
 */
public class NhanVienServiceimpl implements NhanVienService{
    NhanVienResponsitoty nvr=new NhanVienResponsitoty();
    @Override
    public void getAll(List<NhanVien> list) {
        list.addAll(nvr.getAll());
    }

    @Override
    public String layIdCV(String tenCV) {
        return nvr.layIdChucVu(tenCV);
    }

    @Override
    public String layIdCH(String tenCH) {
        return nvr.layIdCuaHang(tenCH);
    }

    @Override
    public List<String> layTenCV(List<String> list) {
        list.addAll(nvr.layTenCV());
        return list;
    }

    @Override
    public List<String> layTenCH(List<String> list) {
        list.addAll(nvr.layTenCH());
        return list;
    }

    @Override
    public String add(NhanVien nv) {
        boolean add=nvr.add(nv);
        if(add==true){
            return "Đăng kí thành công";
        }else{
            return "Đăng kí thất bại";
        }
    }

    
    
}
