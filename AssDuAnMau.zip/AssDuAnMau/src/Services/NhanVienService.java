/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Services;

import java.util.List;
import DomainModel.NhanVien;

/**
 *
 * @author ADMIN
 */
public interface NhanVienService {
    void getAll(List<NhanVien> list);
    String layIdCV(String tenCV);
    String layIdCH(String tenCH);
    List<String> layTenCV(List<String> list);
    List<String> layTenCH(List<String> list);
    String add(NhanVien nv);
}
