/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Services;

import DomainModel.GioHangChiTiet;
import java.util.List;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ADMIN
 */
public interface GioHangChiTietService {
    void getAll(List<GioHangChiTiet> list,String idKH);
    void showData(List<GioHangChiTiet> list,DefaultTableModel dtm);
    String layIdGioHang(String maKH);
    String layIdSanPham(String idSP);
    String layMaGioHang(String id);
    String layTenSanPham(String id);
}
