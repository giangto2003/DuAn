/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author ADMIN
 */
public class NhanVien {
    private String id;
    private String manv;
    private String ten;
    private String tenDem;
    private String ho;
    private String gioiTinh;
    private String ngaySinh;
    private String diaChi;
    private String sdt;
    private String matKhau;

    public NhanVien() {
    }

    public NhanVien(String id, String manv, String ten, String tenDem, String ho, String gioiTinh, String ngaySinh, String diaChi, String sdt, String matKhau) {
        this.id = id;
        this.manv = manv;
        this.ten = ten;
        this.tenDem = tenDem;
        this.ho = ho;
        this.gioiTinh = gioiTinh;
        this.ngaySinh = ngaySinh;
        this.diaChi = diaChi;
        this.sdt = sdt;
        this.matKhau = matKhau;
    }

    public NhanVien(String manv, String ten, String tenDem, String ho, String gioiTinh, String ngaySinh, String diaChi, String sdt, String matKhau) {
        this.manv = manv;
        this.ten = ten;
        this.tenDem = tenDem;
        this.ho = ho;
        this.gioiTinh = gioiTinh;
        this.ngaySinh = ngaySinh;
        this.diaChi = diaChi;
        this.sdt = sdt;
        this.matKhau = matKhau;
    }

    
    public Object[] toDataRow(){
        return new Object[]{manv,ten,tenDem,ho,gioiTinh,ngaySinh,diaChi,sdt,matKhau};
    }
}
