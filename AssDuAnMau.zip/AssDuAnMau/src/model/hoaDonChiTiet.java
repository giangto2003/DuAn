/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author ADMIN
 */
public class hoaDonChiTiet {
    private String idHoaDon;
    private String idChiTietSanPham;
    private int soLuong;
    private int donGia;

    public hoaDonChiTiet() {
    }

    public hoaDonChiTiet(String idHoaDon, String idChiTietSanPham, int soLuong, int donGia) {
        this.idHoaDon = idHoaDon;
        this.idChiTietSanPham = idChiTietSanPham;
        this.soLuong = soLuong;
        this.donGia = donGia;
    }

    public String getIdHoaDon() {
        return idHoaDon;
    }

    public void setIdHoaDon(String idHoaDon) {
        this.idHoaDon = idHoaDon;
    }

    public String getIdChiTietSanPham() {
        return idChiTietSanPham;
    }

    public void setIdChiTietSanPham(String idChiTietSanPham) {
        this.idChiTietSanPham = idChiTietSanPham;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public int getDonGia() {
        return donGia;
    }

    public void setDonGia(int donGia) {
        this.donGia = donGia;
    }
    public Object[] toDataRow(){
        return new Object[]{idHoaDon,idChiTietSanPham,soLuong,donGia};
    }
}
