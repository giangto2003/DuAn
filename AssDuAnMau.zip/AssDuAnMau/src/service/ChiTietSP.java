/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package service;

import java.util.List;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ADMIN
 */
public interface ChiTietSP {
    void showData(List<model.ChiTietSP> list,DefaultTableModel dtm);
    void getAll(List<model.ChiTietSP> list);
    String delete(String id);
    String add(model.ChiTietSP sp);
}
