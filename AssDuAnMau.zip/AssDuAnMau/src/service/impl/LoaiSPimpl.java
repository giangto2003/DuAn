/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service.impl;

import java.util.List;
import javax.swing.DefaultComboBoxModel;
import responsitory.LoaiSPResponsitory;
import service.LoaiSP;

/**
 *
 * @author ADMIN
 */
public class LoaiSPimpl implements LoaiSP{
    LoaiSPResponsitory rs=new LoaiSPResponsitory();
    @Override
    public void getAll(List<model.LoaiSP> list) {
        list.addAll(rs.getAll());
    }

    @Override
    public void layTen(List<String> a, DefaultComboBoxModel dcbb) {
        a.addAll(rs.layTen());
        dcbb.addAll(a);
    }
    
}
