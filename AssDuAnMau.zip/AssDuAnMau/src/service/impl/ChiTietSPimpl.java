/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service.impl;

import java.util.List;
import javax.swing.table.DefaultTableModel;
import responsitory.SanPhamResponsitory;
import service.ChiTietSP;

/**
 *
 * @author ADMIN
 */
public class ChiTietSPimpl implements ChiTietSP{
    SanPhamResponsitory sanPhamResponsitory = new SanPhamResponsitory();

    @Override
    public void showData(List<model.ChiTietSP> list, DefaultTableModel dtm) {
        dtm.setRowCount(0);
        for(model.ChiTietSP c:list){
            dtm.addRow(c.toDataRow());
        }
    }

    @Override
    public void getAll(List<model.ChiTietSP> list) {
        list.addAll(sanPhamResponsitory.getAll());
    }

    @Override
    public String delete(String id) {
        boolean delete=sanPhamResponsitory.deleteSP(id);
        if(delete==true){
            return "Xóa thành công";
        }else{
            return "Xóa thất bại";
        }
    }

    @Override
    public String add(model.ChiTietSP sp) {
        boolean add=sanPhamResponsitory.add(sp);
        if(add){
            return "Thêm thành công";
        }else{
            return "Thêm thất bại";
        }
    }
    

    

    
    
}
