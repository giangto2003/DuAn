/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package responsitory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.ChiTietSP;

/**
 *
 * @author ADMIN
 */
public class SanPhamResponsitory {

    public List<ChiTietSP> getAll() {
        String query = "SELECT ChiTietSP.[Id]\n"
                + "      ,[IdSP]\n"
                + "      ,SanPham.Ma\n"
                + "	  ,SanPham.Ten\n"
                + "      ,[NamBH]\n"
                + "      ,[SoLuongTon]\n"
                + "      ,[GiaNhap]\n"
                + "      ,[GiaBan]\n"
                + "  FROM [dbo].[ChiTietSP]\n"
                + "  join SanPham on SanPham.Id=ChiTietSP.IdSP";
        List<ChiTietSP> list = new ArrayList<>();
        try ( Connection con = DBContext.getConnection();  PreparedStatement ps = con.prepareStatement(query);) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                ChiTietSP chiTietSP = new ChiTietSP(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5), rs.getInt(6), rs.getInt(7), rs.getInt(8));
                list.add(chiTietSP);
            }
            return list;
        } catch (SQLException e) {
            e.printStackTrace(System.out);
        }
        return null;
    }

    public boolean deleteSP(String id) {
        String query = "DELETE FROM [dbo].[ChiTietSP]\n"
                + "      WHERE Id = ?";
        int check = 0;
        try ( Connection con = DBContext.getConnection();  PreparedStatement ps = con.prepareStatement(query);) {
            ps.setObject(1, id);
            check = ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(System.out);
        }
        return check > 0;
    }

    public boolean add(ChiTietSP sp) {
        String query = "INSERT INTO [dbo].[ChiTietSP]\n"
                + "           ([IdSP]\n"
                + "           ,[NamBH]\n"
                + "           ,[SoLuongTon]\n"
                + "           ,[GiaNhap]\n"
                + "           ,[GiaBan])\n"
                + "     VALUES\n"
                + "           (?,?,?,?,?)";
        int check = 0;
        try ( Connection con = DBContext.getConnection();  PreparedStatement ps = con.prepareStatement(query);) {
            ps.setObject(1, sp.getIdSP());
            ps.setObject(2, sp.getNamBH());
            ps.setObject(3, sp.getSoLuongTon());
            ps.setObject(4,sp.getGiaNhap());
            ps.setObject(5, sp.getGiaBan());
            check = ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(System.out);
        }
        return check > 0;
    }
}
