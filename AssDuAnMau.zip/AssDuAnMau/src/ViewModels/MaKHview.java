/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ViewModels;

import java.awt.Label;

/**
 *
 * @author ADMIN
 */
public class MaKHview {
    private String maKH;
    private Label lable1;
    public MaKHview(String maKH) {
        this.maKH = maKH;
    }

    public MaKHview() {
    }
    
    public String getMaKH() {
        return maKH;
    }

    public void setMaKH(String maKH) {
        this.maKH = maKH;
    } 
    public String TenDN(){
        return maKH;
    }

    public Label getLable1() {
        return lable1;
    }

    public void setLable1(Label lable1) {
        this.lable1 = lable1;
        
    }

}
