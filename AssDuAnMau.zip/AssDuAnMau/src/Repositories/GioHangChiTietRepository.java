/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Repositories;

import DomainModel.ChiTietSP;
import DomainModel.GioHangChiTiet;
import Utilities.DBContext;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ADMIN
 */
public class GioHangChiTietRepository {

    public String layIDGioHang(String idKH) {
        String query = "SELECT [Id]\n"
                + "  FROM [dbo].[GioHang]\n"
                + "  where IdKH = ?";
        String a = "";
        try ( Connection con = DBContext.getConnection();  PreparedStatement ps = con.prepareStatement(query);) {
            ps.setObject(1, idKH);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                a = rs.getString(1);
            }
            return a;
        } catch (SQLException e) {
            e.printStackTrace(System.out);
        }
        return null;
    }

    public String layIDSP(String idSP) {
        String query = "SELECT [Id]\n"
                + "  FROM [dbo].[ChiTietSP]\n"
                + "  where IdSP = ?";
        String a = "";
        try ( Connection con = DBContext.getConnection();  PreparedStatement ps = con.prepareStatement(query);) {
            ps.setObject(1, idSP);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                a = rs.getString(1);
            }
            return a;
        } catch (SQLException e) {
            e.printStackTrace(System.out);
        }
        return null;
    }

    public String layMaGioHang(String id) {
        String query = "SELECT [Ma]\n"
                + "  FROM [dbo].[GioHang]\n"
                + "  where Id = ?";
        String a = "";
        try ( Connection con = DBContext.getConnection();  PreparedStatement ps = con.prepareStatement(query);) {
            ps.setObject(1, id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                a = rs.getString(1);
            }
            return a;
        } catch (SQLException e) {
            e.printStackTrace(System.out);
        }
        return null;
    }

    public String layTenSP(String id) {
        String query = "SELECT SanPham.Ten\n"
                + "  FROM [dbo].[ChiTietSP]\n"
                + "  join SanPham on SanPham.Id=ChiTietSP.IdSP\n"
                + "  where ChiTietSP.Id=?";
        String a = "";
        try ( Connection con = DBContext.getConnection();  PreparedStatement ps = con.prepareStatement(query);) {
            ps.setObject(1, id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                a = rs.getString(1);
            }
            return a;
        } catch (SQLException e) {
            e.printStackTrace(System.out);
        }
        return null;
    }

    public List<GioHangChiTiet> getAll(String idKH) {
        String query = "SELECT [IdGioHang]\n"
                + "      ,[IdChiTietSP]\n"
                + "      ,[SoLuong]\n"
                + "      ,SoLuong * DonGia \n"
                + "  FROM [dbo].[GioHangChiTiet]\n"
                + "  join GioHang on GioHang.Id=GioHangChiTiet.IdGioHang\n"
                + "  join ChiTietSP on ChiTietSP.Id=GioHangChiTiet.IdChiTietSP\n"
                + "  where GioHang.IdKH = ?";
        List<GioHangChiTiet> list = new ArrayList<>();
        try ( Connection con = DBContext.getConnection();  PreparedStatement ps = con.prepareStatement(query);) {
            ps.setObject(1, idKH);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                GioHangChiTiet chiTiet = new GioHangChiTiet(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getInt(4));
                list.add(chiTiet);
            }
            return list;
        } catch (SQLException e) {
            e.printStackTrace(System.out);
        }
        return null;
    }
}
