/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DomainModel;

import Repositories.GioHangChiTietRepository;

/**
 *
 * @author ADMIN
 */
public class GioHangChiTiet {
    private String idGioHang;
    private String idChiTietSP;
    private int soLuong;
    private int donGia;
    private GioHangChiTietRepository ghctr=new GioHangChiTietRepository();
    public GioHangChiTiet() {
    }

    public GioHangChiTiet(String idGioHang, String idChiTietSP, int soLuong, int donGia) {
        this.idGioHang = idGioHang;
        this.idChiTietSP = idChiTietSP;
        this.soLuong = soLuong;
        this.donGia = donGia;
    }

    public String getIdGioHang() {
        return idGioHang;
    }

    public void setIdGioHang(String idGioHang) {
        this.idGioHang = idGioHang;
    }

    public String getIdChiTietSP() {
        return idChiTietSP;
    }

    public void setIdChiTietSP(String idChiTietSP) {
        this.idChiTietSP = idChiTietSP;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public int getDonGia() {
        return donGia;
    }

    public void setDonGia(int donGia) {
        this.donGia = donGia;
    }
    public String layMaGioHang(){
        return ghctr.layMaGioHang(idGioHang);
    }
    public String layTenHang(){
        return ghctr.layTenSP(idChiTietSP);
    }
    public Object[] toDataRow(){
        return new Object[]{layMaGioHang(),layTenHang(),soLuong,donGia};
    }
}
